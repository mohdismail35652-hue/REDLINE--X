REDLINE X — Installable PWA

1. Host this folder on HTTPS (for example GitHub Pages, Netlify, or Lovable deployment).
2. Open redline-x-mobile.html through the hosted HTTPS URL in Android Chrome.
3. Tap INSTALL GAME when it appears, or Chrome ⋮ → Add to Home screen / Install app.
4. The service worker caches the game shell and caches the Three.js CDN response after the first online load.
5. Gameplay progress remains stored in the browser's localStorage on each device.

Important: PWA installation requires HTTPS (localhost is also allowed during development).
